# BMLD-Inf2-BMICalcV2

BMI Calculator which logs all Calculator calls

Link to the app: https://bmi-rechner-v2.streamlit.app
